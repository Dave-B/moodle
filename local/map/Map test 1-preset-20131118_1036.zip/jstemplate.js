Y.use("moodle-local_map-map", function() {
	M.local_map.init(load);
});

function load() {
    if (Y.one("#datamap")) {
        M.local_map.maps["datamap"] = M.local_map.addmap("datamap", {center: [46.073, 8.437], zoom: 1});
        // Add entries
        Y.all("#mod-data-map-template .data-entry").each(function (taskNode) {
            var title = taskNode.getElementsByTagName('td').item(1).get('innerHTML');
            var coords = taskNode.getElementsByTagName('td').item(2).get('innerHTML').split(',');
            var desc = taskNode.getElementsByTagName('td').item(3).get('innerHTML');
            var popuptext = '<h3>'+title+'</h3><div>'+desc+'</div>';
            var closebox = '<div><a href="#" id="mapentryremove" title="Hide information">x</a></div>';
            var boxtext = '<div>'+popuptext+closebox+'</div>';
            L.marker([coords[0], coords[1]], {title:title}).addTo(M.local_map.maps["datamap"]).on('click', function(e) {
                Y.one("#datamapinfo").set('innerHTML', boxtext);
                Y.one("#mapentryremove").on('click', function() {
                    Y.one("#datamapinfo").set('innerHTML', '')
                });
            });
        });
        // Hide table and buttons
        Y.one("#mod-data-map-template").insertBefore('<div id="datapanelvis"><input id="showdata" type="button" value="Show data table" /><input id="hidedata" type="button" value="Hide data table" />', 'after');
        var dataelements = Y.all('#mod-data-map-template, #hidedata, #checkall, #checknone, input.form-submit');
        var notdataelements = Y.one('#showdata');
        Y.one('#hidedata').on('click', function() {dataelements.hide();notdataelements.show()});
        Y.one('#showdata').on('click', function() {dataelements.show();notdataelements.hide()});
        notdataelements.hide();dataelements.show()
    }
};
